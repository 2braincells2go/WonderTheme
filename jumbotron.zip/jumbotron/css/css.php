<?php
$themePath = "/themes/jumbotron/";
$coverPath = $themePath."images/covers/";
$tnPath = $themePath."images/thumbnails/";

header("Content-type: text/css; charset: UTF-8");
