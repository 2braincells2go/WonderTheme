<?php
Include ('css.php');
?>

.navbar-brand {
	display: none;
}

#jumbotron-content {
	display: inherit;
}

#homePanel { 
	display: inherit;
}