<?php
Include ('css.php');
?>

.navbar-brand {
	display: none;
}

.jumbotron {
}

#jumbotron-content {
	display: inherit;
}


/* Medium Devices, Desktops */
@media only screen and (min-width : 992px) {
	#homePanel { 
		display: inherit;
	}
}
