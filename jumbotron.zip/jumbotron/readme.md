# Readme

To install this theme, just unzip it into your "themes" folder in WonderCMS. (It should automatically expand into a folder called 'jumbotron').

You will also need to make one modification to your index.php file. On line 21, add:

    include ('themes/jumbotron/default-content.php');

If you have any trouble, please open an issue on the github repo at https://github.com/cristoslc/WonderCMS-Jumbotron/issues
